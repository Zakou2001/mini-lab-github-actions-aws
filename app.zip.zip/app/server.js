const http = require("http");
const url = require("url");

// Configuration
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

// Fonction pour logger avec timestamp
const log = (message) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${message}`);
};

// Fonction pour obtenir l'IP du client
const getClientIP = (req) => {
  return req.headers['x-forwarded-for'] || 
         req.connection.remoteAddress || 
         req.socket.remoteAddress;
};

// Création du serveur HTTP
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;
  const clientIP = getClientIP(req);

  // Log de la requête
  log(`${method} ${pathname} - Client: ${clientIP}`);

  // Configuration des headers CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  // Gestion des différentes routes
  try {
    // Route: Page d'accueil
    if (pathname === '/' && method === 'GET') {
      res.statusCode = 200;
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.end("Hello depuis EC2 de Sidick \n");
    }
    
    // Route: API Info
    else if (pathname === '/api/info' && method === 'GET') {
      res.statusCode = 200;
      const response = {
        message: "API Node.js - Projet DevOps de Sidick",
        version: "1.0.0",
        environment: process.env.NODE_ENV || 'production',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        platform: process.platform,
        nodeVersion: process.version
      };
      res.end(JSON.stringify(response, null, 2));
    }
    
    // Route: Health Check
    else if (pathname === '/health' && method === 'GET') {
      res.statusCode = 200;
      const response = {
        status: "healthy",
        uptime: process.uptime(),
        timestamp: new Date().toISOString(),
        memory: {
          used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + ' MB',
          total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024) + ' MB'
        }
      };
      res.end(JSON.stringify(response, null, 2));
    }
    
    // Route: API Status
    else if (pathname === '/api/status' && method === 'GET') {
      res.statusCode = 200;
      const response = {
        status: "online",
        server: "EC2 - Node.js API",
        author: "Sidick",
        project: "Validation Acquis Cloud & DevOps",
        technologies: ["Node.js", "AWS EC2", "GitHub Actions", "PM2"],
        endpoints: [
          { path: "/", method: "GET", description: "Page d'accueil" },
          { path: "/api/info", method: "GET", description: "Informations sur l'API" },
          { path: "/health", method: "GET", description: "Health check" },
          { path: "/api/status", method: "GET", description: "Status de l'API" },
          { path: "/api/time", method: "GET", description: "Heure du serveur" }
        ]
      };
      res.end(JSON.stringify(response, null, 2));
    }
    
    // Route: Time
    else if (pathname === '/api/time' && method === 'GET') {
      res.statusCode = 200;
      const now = new Date();
      const response = {
        timestamp: now.toISOString(),
        date: now.toLocaleDateString('fr-FR'),
        time: now.toLocaleTimeString('fr-FR'),
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        unix: Math.floor(now.getTime() / 1000)
      };
      res.end(JSON.stringify(response, null, 2));
    }
    
    // Route: Echo (pour tester POST)
    else if (pathname === '/api/echo' && method === 'POST') {
      let body = '';
      
      req.on('data', chunk => {
        body += chunk.toString();
      });
      
      req.on('end', () => {
        res.statusCode = 200;
        const response = {
          message: "Echo successful",
          receivedData: body,
          timestamp: new Date().toISOString()
        };
        res.end(JSON.stringify(response, null, 2));
      });
    }
    
    // Route non trouvée (404)
    else {
      res.statusCode = 404;
      const response = {
        error: "Route not found",
        path: pathname,
        method: method,
        message: "Cette route n'existe pas. Essayez /api/status pour voir les routes disponibles."
      };
      res.end(JSON.stringify(response, null, 2));
    }
    
  } catch (error) {
    // Gestion des erreurs
    log(`ERROR: ${error.message}`);
    res.statusCode = 500;
    const response = {
      error: "Internal Server Error",
      message: error.message
    };
    res.end(JSON.stringify(response, null, 2));
  }
});

// Gestion des erreurs du serveur
server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    log(`ERROR: Port ${PORT} is already in use`);
    process.exit(1);
  } else {
    log(`ERROR: ${error.message}`);
  }
});

// Démarrage du serveur
server.listen(PORT, HOST, () => {
  log(`Server running on http://${HOST}:${PORT}`);
  log(`Environment: ${process.env.NODE_ENV || 'production'}`);
  log(`Node version: ${process.version}`);
  log(`Platform: ${process.platform}`);
  log('-------------------------------------------');
  log('Available endpoints:');
  log('  GET  /              - Page d\'accueil');
  log('  GET  /api/info      - Informations API');
  log('  GET  /health        - Health check');
  log('  GET  /api/status    - Status de l\'API');
  log('  GET  /api/time      - Heure du serveur');
  log('  POST /api/echo      - Echo des données POST');
  log('-------------------------------------------');
});

// Gestion de l'arrêt propre du serveur
process.on('SIGTERM', () => {
  log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    log('HTTP server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  log('SIGINT signal received: closing HTTP server');
  server.close(() => {
    log('HTTP server closed');
    process.exit(0);
  });
});

// Export pour tests (optionnel)
module.exports = server;