#!/bin/bash
cd /opt/app
npm install
node server.js