module.exports = {
  apps: [
    {
      // Configuration de l'application
      name: 'api-sidick',
      script: './server.js',
      
      // Instances
      instances: 1,
      exec_mode: 'fork', // ou 'cluster' pour plusieurs instances
      
      // Variables d'environnement
      env: {
        NODE_ENV: 'development',
        PORT: 3000
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      
      // Logs
      error_file: './logs/error.log',
      out_file: './logs/output.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      
      // Restart strategy
      watch: false, // Activer à true en dev pour auto-restart sur changement
      ignore_watch: ['node_modules', 'logs', '.git'],
      watch_delay: 1000,
      
      // Auto-restart
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      
      // Memory management
      max_memory_restart: '500M',
      
      // Gestion des erreurs
      kill_timeout: 5000,
      wait_ready: false,
      listen_timeout: 3000,
      
      // Instances management (cluster mode)
      // instances: 'max', // Décommenter pour utiliser tous les CPU
      
      // Monitoring
      instance_var: 'INSTANCE_ID',
      
      // Post-deployment hooks (optionnel)
      post_update: ['npm install', 'echo "Application updated"'],
      
      // Cron pour restart automatique (optionnel)
      // cron_restart: '0 0 * * *', // Restart tous les jours à minuit
      
      // Source maps (pour debugging)
      source_map_support: true,
      
      // Time zone
      time: true
    }
  ],
  
  // Configuration du déploiement (optionnel)
  deploy: {
    production: {
      user: 'ec2-user',
      host: ['YOUR-EC2-PUBLIC-IP'],
      ref: 'origin/main',
      repo: 'git@github.com:username/nodejs-api-ec2.git',
      path: '/home/ec2-user/api',
      'pre-deploy-local': '',
      'post-deploy': 'npm install && pm2 reload ecosystem.config.js --env production',
      'pre-setup': '',
      ssh_options: 'StrictHostKeyChecking=no'
    }
  }
};